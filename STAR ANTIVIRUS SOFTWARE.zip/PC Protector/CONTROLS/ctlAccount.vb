﻿Public Class ctlAccount
    Private Sub ctlAccount_Load(sender As Object, e As EventArgs) Handles Me.Load
        MyFunctions.userDetails()
    End Sub
End Class
