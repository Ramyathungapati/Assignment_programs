﻿Public Class ctlPrivacy



    Private Sub PictureBox1_Click(sender As Object, e As EventArgs) Handles PictureBox1.Click
        MyFunctions.username = "freevpn"
        MyFunctions.host = "83.170.115.92"
        MyFunctions.password = "account"
        MyFunctions.location = "USA"
        PictureBox3.Image = PictureBox1.Image
    End Sub

    Private Sub PictureBox2_Click(sender As Object, e As EventArgs) Handles PictureBox2.Click
        MyFunctions.username = "free"
        MyFunctions.host = "65.111.173.161"
        MyFunctions.password = "1234"
        MyFunctions.location = "Canada"
        PictureBox3.Image = PictureBox2.Image
    End Sub

    Private Sub PictureBox4_Click(sender As Object, e As EventArgs) Handles PictureBox4.Click
        MyFunctions.username = "free"
        MyFunctions.host = "108.163.169.44"
        MyFunctions.password = "1234"
        MyFunctions.location = "Germany"
        PictureBox3.Image = PictureBox4.Image
    End Sub

    Private Sub MyButton2_Click(sender As Object, e As EventArgs) Handles MyButton2.Click
        If Not IO.Directory.Exists(System.Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments) & "\vpnconnector") Then
            IO.Directory.CreateDirectory(System.Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments) & "\vpnconnector")
        End If

        IO.File.WriteAllText((System.Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments) & "\vpnconnector" & "connection.pbk"), "[VPN]" & vbNewLine & "MEDIA=rastapi" & "Port=VPN2-0" & vbNewLine & "Device=WAN Miniport (IKEv2)" & vbNewLine & "DEVICE=vpn" & vbNewLine & "PhoneNumber=" & MyFunctions.host)
        IO.File.WriteAllText((System.Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments) & "\vpnconnector" & "\connection.bat"), "rasdial ""VPN"" " & MyFunctions.username & " " & MyFunctions.password & " /phonebook:" & """" & System.Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments) & "\vpnconnector" & "\connection.pbk" & """")
        Dim connect As System.Diagnostics.Process
        connect = New System.Diagnostics.Process()
        connect.StartInfo.FileName = System.Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments) & "\vpnconnector" & "\connection.bat"
        connect.StartInfo.WindowStyle = ProcessWindowStyle.Normal
        connect.Start()
        connect.WaitForExit()



        If connect.ExitCode Then
            Label1.Text = "CONNECTED - YOUR IP ADDRESS IS " & MyFunctions.host
            Label1.ForeColor = Color.Green
            PictureBox8.Image = My.Resources.connected
            Label2.Text = "You are Connected to " & MyFunctions.location
            MyButton2.Enabled = False
            MyButton1.Enabled = True
            Panel1.Visible = False

        End If

    End Sub

    Private Sub MyButton1_Click(sender As Object, e As EventArgs) Handles MyButton1.Click
        IO.File.WriteAllText((System.Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments) & "\vpnconnector" & "\disconnect.bat"), "rasdial/d")
        Dim connect As System.Diagnostics.Process
        connect = New System.Diagnostics.Process()
        connect.StartInfo.FileName = System.Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments) & "\vpnconnector" & "\disconnect.bat"
        connect.StartInfo.WindowStyle = ProcessWindowStyle.Normal

        connect.Start()
        connect.WaitForExit()

        Label1.Text = "VPN Disconnected"
        Label1.ForeColor = Color.White
        PictureBox8.Image = My.Resources.disconnected
        Label2.Text = "Choose Country "
        MyButton2.Enabled = True
        MyButton1.Enabled = False
        Panel1.Visible = True
    End Sub
End Class
