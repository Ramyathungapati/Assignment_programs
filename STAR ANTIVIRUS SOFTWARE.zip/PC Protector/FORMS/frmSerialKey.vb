﻿Public Class frmSerialKey
    Private Sub LinkLabel1_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles LinkLabel1.LinkClicked
        Process.Start(MyStrings.SubscriptionLink)
    End Sub

    Private Sub btnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click
        Me.Close()

    End Sub

    Private Sub MyButton3_Click(sender As Object, e As EventArgs) Handles MyButton3.Click
        If TextBox1.Text = Nothing And TextBox2.Text = Nothing Then
            MsgBox("Please Enter Email/Serial Key to continue", MsgBoxStyle.Information)
        Else
            If TextBox1.Text = Nothing Then
                MsgBox("Please Enter Email to continue", MsgBoxStyle.Information)
            Else
                If TextBox2.Text = Nothing Then
                    MsgBox("Please Enter Serial Key to continue", MsgBoxStyle.Information)
                Else
                    If TextBox2.Text = My.Settings.monthKey Then
                        My.Settings.ActivationStatus = True
                        My.Settings.serialKey = TextBox2.Text
                        My.Settings.email = TextBox1.Text
                        My.Settings.expiry = "Monthly Subscription"
                        My.Settings.validation = "31 Days Activated"

                        My.Settings.Save()
                        Application.Restart()
                    Else
                        If TextBox2.Text = My.Settings.yearKey Then
                            My.Settings.ActivationStatus = True
                            My.Settings.serialKey = TextBox2.Text
                            My.Settings.email = TextBox1.Text
                            My.Settings.expiry = "Yearly Subscription"
                            My.Settings.validation = "360 Days Activated"
                            My.Settings.Save()
                            Application.Restart()
                        Else
                            If TextBox2.Text = My.Settings.liftimeKey Then
                                My.Settings.ActivationStatus = True
                                My.Settings.serialKey = TextBox2.Text
                                My.Settings.email = TextBox1.Text
                                My.Settings.expiry = "One Time Subscription"
                                My.Settings.validation = "Unlimited"
                                My.Settings.Save()

                                Application.Restart()
                            Else
                                MsgBox("Invalid Serial Key / Email, Please Contact us for support", MsgBoxStyle.Information)
                            End If
                        End If
                    End If
                End If

            End If
        End If
    End Sub
End Class