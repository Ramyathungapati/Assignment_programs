﻿Public Class frmSettings
    Private Sub Panel1_Paint(sender As Object, e As PaintEventArgs) Handles Panel1.Paint

    End Sub

    Private Sub btnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click
        Me.Close()

    End Sub

    Private Sub CheckBox1_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox1.CheckedChanged
        Dim applicationName As String = Application.ProductName
        Dim applcationPath As String = Application.ExecutablePath

        If CheckBox1.Checked Then
            Dim regKey As Microsoft.Win32.RegistryKey
            regKey = Microsoft.Win32.Registry.CurrentUser.OpenSubKey("SOFTWARE\Microsoft\Windows\CurrentVersion\Run", True)
            regKey.SetValue(applicationName, """" & applcationPath & """")
            regKey.Close()
            My.Settings.startup = True
            My.Settings.Save()

        Else
            Dim regKey As Microsoft.Win32.RegistryKey
            regKey = Microsoft.Win32.Registry.CurrentUser.OpenSubKey("SOFTWARE\Microsoft\Windows\CurrentVersion\Run", True)
            regKey.Close()
            My.Settings.startup = False
            My.Settings.Save()

        End If
    End Sub

    Private Sub MyButton3_Click(sender As Object, e As EventArgs) Handles MyButton3.Click
        If CheckBox3.Checked = True Then
            Timer1.Interval = 10000
            Timer1.Start()
        End If

        If CheckBox2.Checked = True Then

        End If

        If CheckBox1.Checked = True Then
            My.Settings.bootUp = True
            My.Settings.Save()
        Else
            If CheckBox2.Checked = True Then
                My.Settings.startVPN = True
                My.Settings.Save()
            Else
                If CheckBox3.Checked = True Then
                    My.Settings.scan1hour = True
                    My.Settings.Save()
                End If
            End If
        End If

        MsgBox("Settings Saved Successfully!", MsgBoxStyle.Information, "Attention!")

        Me.Close()
    End Sub



    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        ProgressBar1.Increment(1)
        If ProgressBar1.Value = 100 Then
            Timer1.Stop()
            ProgressBar1.Value = 0
            MyFunctions.Scan()
            Timer1.Start()
        End If
    End Sub

    Private Sub CheckBox2_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox2.CheckedChanged

    End Sub
End Class