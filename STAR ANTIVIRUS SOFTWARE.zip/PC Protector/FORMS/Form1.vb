﻿
Imports System.Runtime.InteropServices

Public Class Form1

    Private Sub Form1_MouseDown(sender As Object, e As MouseEventArgs) Handles Me.MouseDown, HeaderPanel.MouseDown, lblTitle.MouseDown
        If e.Button = Windows.Forms.MouseButtons.Left Then
            MyFunctions.ReleaseCapture()
            MyFunctions.SendMessage(Handle, MyFunctions.WM_NCLBUTTONDOWN, MyFunctions.HT_CAPTION, 0)
        End If
    End Sub

    Private Sub btnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click
        frmPopup.ShowDialog()
    End Sub

    Private Sub btnMinimize_Click(sender As Object, e As EventArgs) Handles btnMinimize.Click
        Me.WindowState = FormWindowState.Minimized
    End Sub

    Private Sub btnDashboaard_Click(sender As Object, e As EventArgs) Handles btnDashboaard.Click
        CtlDashboard1.BringToFront()
        CtlDashboard1.Visible = True
        With btnDashboaard
            .BottomColor = MyColors.active_color1
            .TopColor = MyColors.active_color2
        End With

        imgDashbaord.BackColor = MyColors.imageActiveColor

        With btnProtection
            .BottomColor = MyColors.deactive_color1
            .TopColor = MyColors.deactive_color2
        End With
        imgProtection.BackColor = MyColors.imageDeactiveColor

        With btnPrivacy
            .BottomColor = MyColors.deactive_color1
            .TopColor = MyColors.deactive_color2
        End With
        imgPrivacy.BackColor = MyColors.imageDeactiveColor

        With btnNotification
            .BottomColor = MyColors.deactive_color1
            .TopColor = MyColors.deactive_color2
        End With
        imgNotification.BackColor = MyColors.imageDeactiveColor

        With btnAccount
            .BottomColor = MyColors.deactive_color1
            .TopColor = MyColors.deactive_color2
        End With
        imgAccount.BackColor = MyColors.imageDeactiveColor


    End Sub

    Private Sub btnProtection_Click(sender As Object, e As EventArgs) Handles btnProtection.Click
        CtlScanCenter1.BringToFront()
        CtlScanCenter1.Visible = True
        With btnDashboaard
            .BottomColor = MyColors.deactive_color1
            .TopColor = MyColors.deactive_color2
        End With
        imgDashbaord.BackColor = MyColors.imageDeactiveColor


        With btnProtection
            .BottomColor = MyColors.active_color1
            .TopColor = MyColors.active_color2

        End With
        imgProtection.BackColor = MyColors.imageActiveColor

        With btnPrivacy
            .BottomColor = MyColors.deactive_color1
            .TopColor = MyColors.deactive_color2
        End With
        imgPrivacy.BackColor = MyColors.imageDeactiveColor

        With btnNotification
            .BottomColor = MyColors.deactive_color1
            .TopColor = MyColors.deactive_color2
        End With
        imgNotification.BackColor = MyColors.imageDeactiveColor

        With btnAccount
            .BottomColor = MyColors.deactive_color1
            .TopColor = MyColors.deactive_color2
        End With
        imgAccount.BackColor = MyColors.imageDeactiveColor


    End Sub

    Private Sub btnPrivacy_Click(sender As Object, e As EventArgs) Handles btnPrivacy.Click
        MyFunctions.privacyClick()
        If My.Settings.ActivationStatus = False Then
            CtlPremium1.BringToFront()
            CtlPremium1.Visible = True
        Else
            CtlPrivacy1.BringToFront()
            CtlPrivacy1.Visible = True
        End If



    End Sub

    Private Sub btnNotification_Click(sender As Object, e As EventArgs) Handles btnNotification.Click
        MyFunctions.systemPerformance()
        If My.Settings.ActivationStatus = False Then
            CtlPremium1.BringToFront()
            CtlPremium1.Visible = True
        Else
            CtlSystemPerformance1.BringToFront()
            CtlSystemPerformance1.Visible = True
        End If

    End Sub

    Private Sub btnAccount_Click(sender As Object, e As EventArgs) Handles btnAccount.Click
        ctlAccount1.bringtofront
        ctlAccount1.visible = True
        With btnDashboaard
            .BottomColor = MyColors.deactive_color1
            .TopColor = MyColors.deactive_color2
        End With
        imgDashbaord.BackColor = MyColors.imageDeactiveColor

        With btnProtection
            .BottomColor = MyColors.deactive_color1
            .TopColor = MyColors.deactive_color2

        End With
        imgProtection.BackColor = MyColors.imageDeactiveColor

        With btnPrivacy
            .BottomColor = MyColors.deactive_color1
            .TopColor = MyColors.deactive_color2
        End With
        imgPrivacy.BackColor = MyColors.imageDeactiveColor

        With btnNotification
            .BottomColor = MyColors.deactive_color1
            .TopColor = MyColors.deactive_color2
        End With
        imgNotification.BackColor = MyColors.imageDeactiveColor

        With btnAccount
            .BottomColor = MyColors.active_color1
            .TopColor = MyColors.active_color2
        End With
        imgAccount.BackColor = MyColors.imageActiveColor


    End Sub

    Private Sub btnPref_Click(sender As Object, e As EventArgs)
        With btnDashboaard
            .BottomColor = MyColors.deactive_color1
            .TopColor = MyColors.deactive_color2
        End With
        imgDashbaord.BackColor = MyColors.imageDeactiveColor

        With btnProtection
            .BottomColor = MyColors.deactive_color1
            .TopColor = MyColors.deactive_color2

        End With
        imgProtection.BackColor = MyColors.imageDeactiveColor

        With btnPrivacy
            .BottomColor = MyColors.deactive_color1
            .TopColor = MyColors.deactive_color2
        End With
        imgPrivacy.BackColor = MyColors.imageDeactiveColor

        With btnNotification
            .BottomColor = MyColors.deactive_color1
            .TopColor = MyColors.deactive_color2
        End With
        imgNotification.BackColor = MyColors.imageDeactiveColor

        With btnAccount
            .BottomColor = MyColors.deactive_color1
            .TopColor = MyColors.deactive_color2
        End With
        imgAccount.BackColor = MyColors.imageDeactiveColor


    End Sub

    Private Sub btnHelp_Click(sender As Object, e As EventArgs)
        With btnDashboaard
            .BottomColor = MyColors.deactive_color1
            .TopColor = MyColors.deactive_color2
        End With
        imgDashbaord.BackColor = MyColors.imageDeactiveColor

        With btnProtection
            .BottomColor = MyColors.deactive_color1
            .TopColor = MyColors.deactive_color2

        End With
        imgProtection.BackColor = MyColors.imageDeactiveColor

        With btnPrivacy
            .BottomColor = MyColors.deactive_color1
            .TopColor = MyColors.deactive_color2
        End With
        imgPrivacy.BackColor = MyColors.imageDeactiveColor

        With btnNotification
            .BottomColor = MyColors.deactive_color1
            .TopColor = MyColors.deactive_color2
        End With
        imgNotification.BackColor = MyColors.imageDeactiveColor

        With btnAccount
            .BottomColor = MyColors.deactive_color1
            .TopColor = MyColors.deactive_color2
        End With
        imgAccount.BackColor = MyColors.imageDeactiveColor


    End Sub

    Private Sub imgPref_Click(sender As Object, e As EventArgs) Handles imgPref.Click
        frmSettings.ShowDialog()
    End Sub

    Private Sub imgHelp_Click(sender As Object, e As EventArgs) Handles imgHelp.Click
        Process.Start("https://www.google.com")
    End Sub

    Private Sub MyButton8_Click(sender As Object, e As EventArgs) Handles MyButton8.Click
        CtlSubscription1.BringToFront()
        CtlSubscription1.Visible = True

    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles Me.Load


        If My.Settings.ActivationStatus = True Then
            lblTitle.Text = "Star Antivirus - " & My.Settings.validation
            MyButton8.Visible = False
        Else
            MyButton8.Visible = True

        End If
        If My.Settings.startVPN = True Then
            MyFunctions.startVPN()

        End If

        If My.Settings.scan1hour = True Then
            MyFunctions.Scan()

        End If

        If My.Settings.ActivationStatus = False Then
            CtlSubscription1.BringToFront()
            CtlSubscription1.Visible = True
        End If
    End Sub
End Class
