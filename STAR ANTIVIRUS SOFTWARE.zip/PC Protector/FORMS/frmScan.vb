﻿Imports System.IO
Imports System.Security.Cryptography
Imports System.Text
Imports Microsoft.VisualBasic.CompilerServices
Public Class frmScan
    Private Sub btnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click
        Me.Hide()
    End Sub

    Private Sub btnMinimize_Click(sender As Object, e As EventArgs)
        Me.WindowState = FormWindowState.Maximized
    End Sub

    Private Sub PictureBox1_Click(sender As Object, e As EventArgs) Handles PictureBox1.Click
        If FolderBrowserDialog1.ShowDialog = Windows.Forms.DialogResult.OK Then
            ListBox1.Items.Clear()
            MyButton1.Enabled = True
        Else
            Exit Sub
        End If

        On Error Resume Next

        For Each strFile As String In System.IO.Directory.GetFiles(FolderBrowserDialog1.SelectedPath, "*.*", IO.SearchOption.AllDirectories)
            ListBox1.Items.Add(strFile)
        Next
        Timer1.Start()
    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        ProgressBar1.Maximum = CInt(Conversions.ToString(ListBox1.Items.Count))
        lblTotal.Text = Conversions.ToString(ListBox1.Items.Count)
        ListBox1.Enabled = False
        If Not ProgressBar1.Value = ProgressBar1.Maximum Then
            Try
                ListBox1.SelectedIndex = ListBox1.SelectedIndex + 1
                lbllast.Text = ListBox1.SelectedItem.ToString
            Catch ex As Exception
                MsgBox(ex.Message)
            End Try

            Try
                Dim scanbox As New TextBox
                Dim read As String = My.Computer.FileSystem.ReadAllText("main.db").ToString
                ProgressBar1.Increment(1)
                lblVirus.Text = Conversions.ToString(ListBox2.Items.Count)
                lblTotal.Text = Conversions.ToString(ProgressBar1.Value)
                scanbox.Text = read.ToString
                Dim md5 As MD5CryptoServiceProvider = New MD5CryptoServiceProvider
                Dim fs As FileStream = New FileStream(CStr(ListBox1.SelectedItem), FileMode.Open, FileAccess.Read, FileShare.Read, 8192)
                md5.ComputeHash(fs)
                fs.Close()
                Dim hash As Byte() = md5.Hash
                Dim buff As StringBuilder = New StringBuilder
                Dim hashByte As Byte
                For Each hasByte In hash
                    buff.Append(String.Format("{0:X2}", hashByte))
                Next

                If scanbox.Text.Contains(buff.ToString) Then
                    ListBox2.Items.Add(ListBox1.SelectedItem)

                End If


            Catch ex As Exception
                MsgBox(ex.Message)
            End Try
        Else
            ListBox1.Enabled = True
            Timer1.Stop()
            If ListBox2.Items.Count > 0 Then
                MessageBox.Show("Scanning has been completed. There was " & vbCrLf & ListBox2.Items.Count & " viruses detectedd. Please review the list and choose an action.", CStr(MessageBoxButtons.OK))
                MyButton1.Enabled = False
                MyButton3.Enabled = True
                MyButton4.Enabled = True
                Exit Sub
            End If
            MessageBox.Show("Scanning has been completed." & vbCrLf & " No virus was found", CStr(MessageBoxButtons.OK))
            ProgressBar1.Value = 0
        End If
    End Sub

    Private Sub MyButton1_Click(sender As Object, e As EventArgs) Handles MyButton1.Click
        If MessageBox.Show("Are you sure you  want to abort the scan?", "Confirmation", MessageBoxButtons.YesNo) <> DialogResult.Yes Then
            Timer1.Stop()
            If ListBox2.Items.Count > 0 Then
                MsgBox("Scanning has been completed. There was " & vbCrLf & ListBox2.Items.Count & " viruses detectedd. Please review the list and choose an action.", CStr(MessageBoxButtons.OK))
                Timer1.Stop()
                ProgressBar1.Value = 0
                MyButton1.Enabled = False
                MyButton3.Enabled = True
                MyButton4.Enabled = True
            Else
                MessageBox.Show("Scanning has been completed." & vbCrLf & " No virus was found", CStr(MessageBoxButtons.OK))
                Timer1.Stop()
                ProgressBar1.Value = 0
                MyButton1.Enabled = False

            End If
        End If
    End Sub

    Private Sub PictureBox2_Click(sender As Object, e As EventArgs) Handles PictureBox2.Click
        FolderBrowserDialog1.SelectedPath = "C:\"

        On Error Resume Next

        For Each strDir As String In System.IO.Directory.GetDirectories(FolderBrowserDialog1.SelectedPath, "*.*", IO.SearchOption.TopDirectoryOnly)
            For Each strFile As String In System.IO.Directory.GetFiles(strDir, "*.*", SearchOption.AllDirectories)
                ListBox1.Items.Add(strFile)
            Next
        Next

        MyButton1.Enabled = False
        MyButton3.Enabled = True
        MyButton4.Enabled = True
        Timer1.Start()
        ProgressBar1.Visible = False


    End Sub

    Private Sub HeaderPanel_MouseDown(sender As Object, e As MouseEventArgs) Handles HeaderPanel.MouseDown
        If e.Button = Windows.Forms.MouseButtons.Left Then
            MyFunctions.ReleaseCapture()
            MyFunctions.SendMessage(Handle, MyFunctions.WM_NCLBUTTONDOWN, MyFunctions.HT_CAPTION, 0)
        End If
    End Sub

    Private Sub MyButton3_Click(sender As Object, e As EventArgs) Handles MyButton3.Click

    End Sub

    Private Sub MyButton4_Click(sender As Object, e As EventArgs) Handles MyButton4.Click

    End Sub
End Class