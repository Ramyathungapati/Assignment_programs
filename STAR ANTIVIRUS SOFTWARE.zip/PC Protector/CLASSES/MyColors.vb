﻿Public Class MyColors
    Public Shared active_color1 As Color = Color.Blue
    Public Shared active_color2 As Color = Color.Gray

    Public Shared deactive_color1 As Color = Color.FromArgb(18, 23, 30)
    Public Shared deactive_color2 As Color = Color.Gray

    Public Shared imageActiveColor As Color = Color.Blue
    Public Shared imageDeactiveColor As Color = Color.FromArgb(18, 23, 30)



End Class
