﻿Public Class MyStrings

    Public Shared HelpLink = "https://www.google.com"
    Public Shared SubscriptionLink = "https://www.google.com"

End Class
